def send_kwai(message: str):
    return {
        "status": "OK",
        "message": "Kwai API ainda não pública. Endpoint preparado para integração futura."
    }
