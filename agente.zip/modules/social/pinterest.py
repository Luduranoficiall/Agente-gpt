def send_pinterest(message: str):
    return {
        "status": "OK",
        "message": "API do Pinterest requer OAuth. Endpoint pronto para receber credenciais."
    }
