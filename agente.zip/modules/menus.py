# Stub de menus para agente GPT

def main_menu():
    return {'menu': 'principal', 'opcoes': ['Início', 'Afiliados', 'Mentoria', 'Economia', 'Social']}

def social_menu():
    return {'menu': 'social', 'opcoes': ['WhatsApp', 'Telegram', 'Instagram', 'Facebook', 'X', 'TikTok']}
