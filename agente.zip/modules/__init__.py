# Inicializador de pacotes dos módulos da EXTRAORDINARI.A
# Mantém tudo organizado e reconhecido pelo Python.
