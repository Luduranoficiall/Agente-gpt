export default function Network() {
  return (
    <div className="p-10">
      <h1 className="text-2xl font-bold">Rede & Distribuição</h1>

      <p className="mt-4">Em breve: gráfico dos níveis, ganhos, rede e uplines.</p>
    </div>
  );
}
