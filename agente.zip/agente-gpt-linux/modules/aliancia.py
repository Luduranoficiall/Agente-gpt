
from .utils import emit_humanized

def build_affiliates_backend(session, cfg):
    return emit_humanized("ALIANCIA", "Backend afiliados: 25/10/5 (stub).")
