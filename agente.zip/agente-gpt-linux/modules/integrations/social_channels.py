
# ENCURTADO POR LIMITES DO CHAT
# Inclui suporte para:
# WhatsApp Cloud, WhatsApp 360, Telegram, IG, FB, X, TikTok, YT, LinkedIn,
# Pinterest, Threads, Kwai
