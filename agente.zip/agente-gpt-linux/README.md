
# AGENTE GPT — INSTALADOR COMPLETO (PYTHON)

Rodar:

    python3 agente_gpt_instalador.py

Depois:

    cp .env.example .env
    docker compose up -d --build

Dashboard:

    http://localhost:8080
