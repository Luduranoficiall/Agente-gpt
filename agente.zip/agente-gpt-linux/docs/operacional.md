# DOCUMENTAÇÃO OPERACIONAL — EQUIPE INTERNA

## Implementação
1. Rodar installer
2. Subir Docker
3. Configurar .env
4. Ativar WhatsApp
5. Ativar Telegram
6. Criar agente cliente
7. Testar canais

## Atendimento
- Usar comando "menu"
- Ver tarefas em /tasks
- Reenviar mensagens multicanal
- Criar demandas para IA

## Comercial
- Explicar ALIANCI.A
- Mostrar painel
- Demonstrar automações
