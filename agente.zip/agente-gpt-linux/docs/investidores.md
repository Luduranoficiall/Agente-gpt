# DOCUMENTAÇÃO INVESTIDORES — AGENTE GPT

## Oportunidade
Mercado global de US$ 385B/ano (IA + automação + bots).

## Tese
Empresas não querem "ferramentas".  
Querem **inteligência que executa**.

## Modelo de Receita
1. Assinaturas (R$197 / R$397 / R$997)
2. Comissões (25/10/5)
3. White label (BOTGPT)

## Diferenciais
- IA Multiagente
- Multicanal real
- Multi-tenant
- Enterprise-grade
