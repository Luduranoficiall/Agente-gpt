export default function Home() {
  return (
    <div style={{padding:40, fontFamily:'Arial'}}>
      <h1>🔥 Painel Agente GPT</h1>
      <ul>
        <li><a href="/afiliados">Afiliados</a></li>
        <li><a href="/economia">ECONOMI.A</a></li>
        <li><a href="/auria">AURI.A</a></li>
        <li><a href="/social">Social Channels</a></li>
        <li><a href="/demandas">Demandas de Clientes</a></li>
      </ul>
    </div>
  )
}
