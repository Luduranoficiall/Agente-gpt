def salvar_mensagem(telefone, texto, resposta):
    pass
