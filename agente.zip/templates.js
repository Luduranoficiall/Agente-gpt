export const templates = {
  boas_vindas: (nome) => `\nOlá ${nome}! 😄✨\nEu sou o *Agente Extraordinária.AI*.\n\nEstou aqui para ajudar de forma simples, humana e inteligente.\nComo posso te ajudar hoje?\n`,
  erro_padrao: `\nOps... tive uma instabilidade momentânea.  \nPode me enviar sua mensagem novamente? 🙏\n`
};
